#ifndef CAMERAFOLLOWCOMPONENT_H
#define CAMERAFOLLOWCOMPONENT_H

struct CameraFollowComponent {
    CameraFollowComponent() = default;
};

#endif
